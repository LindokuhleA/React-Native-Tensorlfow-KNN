import React from 'react';
import {
  SafeAreaView
} from 'react-native';
import LindoApp from '../../LindoApp';

export default window.ProductScreen = () => {
  return(
    <SafeAreaView 
      // style={{ 
      //   paddingTop: 10,
      //   alignContent: center,
      //   alignItems: center
        
      //   }}>

      >
      <LindoApp />
    </SafeAreaView>
  )
}