import React from 'react';
import {
  View,
  SafeAreaView,
  Text,
  StyleSheet,
  FlatList,
  Image,
  Dimensions,
} from 'react-native';
import {TextInput, TouchableOpacity} from 'react-native';
import Icon from '@expo/vector-icons/MaterialIcons';
//import COLORS from '../../consts/colors';
//import products from '../../consts/products';
const width = Dimensions.get('window').width / 2 - 30;

const COLORS = {
    white: '#fff',
    dark: '#000',
    red: '#F52A2A',
    light: '#F1F1F1',
    pink: '#fc084d',
};
const products = [
    {
      id: 1,
      name: 'Clarifying Carrot Milk',
      price: '39.99',
      like: true,
      img: require('./pictures/carrotmilk.png'),
      about:
        'Improved blemished and damaged skin appearance with our Clarifying Carrot milk. It reduces pigmentation irregularities while evening skin tone. Further, it has anti-oxidant and anti-aging properties leaving your skin smooth and relaxed.',
    },
  
    {
      id: 2,
      name: 'Clarifying Beauty Milk',
      price: '29.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        'It contains whitening, soothing and hydrating agents. It acts against pigmentary imperfections, promotes cell renewal and hydrates the skin.',
    },
    {
      id: 3,
      name: 'Calming Baby Milk',
      price: '25.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        "Protect your baby`s skin against dryness and irritation with our calming Baby Milk. Containing Linden extract to help soothe and calm your baby and their skin with its emollient properties.",
    },
  
    {
      id: 4,
      name: 'Moisturizing Milk',
      price: '25.99',
      like: true,
      img: require('./pictures/carrotmilk.png'),
      about:
        'Its very complete formula (but WITHOUT whitening ingredient) brings to the skin softness, hydration and smoothness.',
    },
    {
      id: 5,
      name: 'Lightening Clarifying Milk Mini-Tubes',
      price: '50.99',
      like: true,
      img: require('./pictures/carrotmilk.png'),
      about:
        'Perfect for your vanity or handbag, these mini-tubes are a must for on-the-go ladies or to use as a tester for our Clarifying Milk. It acts against pigmentary imperfections, promotes cell renewal while hydrating the skin.',
    },
    {
      id: 6,
      name: 'Clarifying Glycerin',
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        'Glycerin, combined to whitening agents, acts against pigmentary imperfections and hydrates the skin. Therefore, after this treatment, your skin is beautiful and shiny. It particularly helps very dry skins.',
    },
    {
      id: 7,
      name: 'Savon Exfoliant Clarifiant', 
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'), 
      about:
        '',
    },
    {
      id: 8,
      name: 'Clarifying Serum',
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        'Because of its high concentration in active ingredients, a small quantity is sufficient for good skin care. It has a hydrating, firming and lightening action.',
    },
    {
      id: 9,
      name: 'Clarifying Day Cream',
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        'It promotes cell renewal and protects against UV-irradiation throughout the day. It also acts against pigmentary imperfections.',
    },
    {
      id: 10,
      name: 'Clarifying Night Cream',
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
        'This cream is rich, hydrating and nourishing, and synergizes with the well-being effects of the night. Its soothing and anti-ageing effects promote skin rejuvenation, unification of skin tone and a velvet feel.',
    },
    {
      id: 11,
      name: 'Purifying Cleansing Bar',
      price: '50.99',
      like: false,
      img: require('./pictures/carrotmilk.png'),
      about:
      'It removes superficial dead cells and hydrates the skin, which is, then, ready to receive treatment with the other KLARIS products.',
    },
  ];
  
 

export default window.Profile = ({navigation}) => {
  const [catergoryIndex, setCategoryIndex] = React.useState(0);

  const categories = ['LATEST', 'ALL','MILK PRODUCTS', 'CREAMS', 'GLYCERIN', 'SERUMS', 'SOAPS'];

  const CategoryList = () => {
    return (
      <View style={style.categoryContainer}>
        {categories.map((item, index) => (
          <TouchableOpacity
            horizontal
            showsHorizontalScrollIndicator={false}
            key={index}
            activeOpacity={0.8}
            onPress={() => setCategoryIndex(index)}>
            <Text
              style={[
                style.categoryText,
                catergoryIndex === index && style.categoryTextSelected,
              ]}>
              {item}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const Card = ({product}) => {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => navigation.navigate('Details', product)}>
        <View style={style.card}>
          <View style={{alignItems: 'flex-end'}}>
            <View
              style={{
                width: 30,
                height: 30,
                borderRadius: 20,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: product.like
                  ? 'rgba(245, 42, 42,0.2)'
                  : 'rgba(0,0,0,0.2) ',
              }}>
              <Icon
                name="favorite"
                size={18}
                color={product.like ? COLORS.red : COLORS.black}
              />
            </View>
          </View>

          <View
            style={{
              height: 100,
              alignItems: 'center',
            }}>
            <Image
              source={product.img}
              style={{flex: 1, resizeMode: 'contain'}}
            />
          </View>

          <Text style={{fontWeight: 'bold', fontSize: 17, marginTop: 10}}>
            {product.name}
          </Text>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: 5,
            }}>
            <Text style={{fontSize: 19, fontWeight: 'bold'}}>
              R{product.price}
            </Text>
            <View
              style={{
                height: 25,
                width: 25,
                backgroundColor: COLORS.pink,
                borderRadius: 5,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text
                style={{fontSize: 22, color: COLORS.white, fontWeight: 'bold'}}>
                +
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView
      style={{flex: 1, paddingHorizontal: 20, backgroundColor: COLORS.white}}>
      <View style={style.header}>
        <View>
          <Text style={{fontSize: 25, fontWeight: 'bold'}}>Welcome to</Text>
          <Text style={{fontSize: 20, color: COLORS.pink, fontWeight: 'bold'}}>
            Klaris De Suisse Cosmetic App
          </Text>
        </View>
        <Icon name="shopping-cart" size={28} />
      </View>
      <View style={{marginTop: 30, flexDirection: 'row'}}>
        <View style={style.searchContainer}>
          <Icon name="search" size={25} style={{marginLeft: 20}} />
          <TextInput placeholder="Search" style={style.input} />
        </View>
        <View style={style.sortBtn}>
          <Icon name="sort" size={30} color={COLORS.white} />
        </View>
      </View>
      <CategoryList />
      <FlatList
        columnWrapperStyle={{justifyContent: 'space-between'}}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          marginTop: 10,
          paddingBottom: 50,
        }}
        numColumns={2}
        data={products}
        renderItem={({item}) => {
          return <Card product={item} />;
        }}
      />
    </SafeAreaView>
  );
};

const style = StyleSheet.create({
  categoryContainer: {
    flexDirection: 'row',
    marginTop: 30,
    marginBottom: 20,
    justifyContent: 'space-between',
  },
  categoryText: {fontSize: 16, color: 'grey', fontWeight: 'bold'},
  categoryTextSelected: {
    color: COLORS.pink,
    paddingBottom: 5,
    borderBottomWidth: 2,
    borderColor: COLORS.pink,
  },
  card: {
    height: 225,
    backgroundColor: COLORS.light,
    width,
    marginHorizontal: 2,
    borderRadius: 10,
    marginBottom: 20,
    padding: 15,
  },
  header: {
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  searchContainer: {
    height: 50,
    backgroundColor: COLORS.light,
    borderRadius: 10,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    color: COLORS.dark,
  },
  sortBtn: {
    marginLeft: 10,
    height: 50,
    width: 50,
    borderRadius: 10,
    backgroundColor: COLORS.pink,
    justifyContent: 'center',
    alignItems: 'center',
  },
});


