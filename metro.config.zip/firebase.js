import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyCL4vw01SHy6XtzOfQHRdoiU9-mgjcF3KU",
  authDomain: "klaris-project.firebaseapp.com",
  projectId: "klaris-project",
  storageBucket: "klaris-project.appspot.com",
  messagingSenderId: "271010509450",
  appId: "1:271010509450:web:07d9626a515bce154cb373"
};

const app = initializeApp(firebaseConfig);
export const authentication = getAuth(app);
export const db = getFirestore(app);
